<div class="container mx-auto">
    <div class="overflow-x-auto">
        <table class="table w-full">
            <thead>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.table-titles','data' => ['addAction' => ''.e($addAction).'','title' => ''.e($slot->isNotEmpty() ? 'title':'Press + to Add New Item').'','delbtn' => ''.e($slot ?? false).'','id' => ''.e($id ?? '').'']]); ?>
<?php $component->withName('table-titles'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['addAction' => ''.e($addAction).'','title' => ''.e($slot->isNotEmpty() ? 'title':'Press + to Add New Item').'','delbtn' => ''.e($slot ?? false).'','id' => ''.e($id ?? '').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </thead>
            <tbody>
            <?php echo e($slot); ?>

            </tbody>
            <tfoot>
            <?php if($slot->isNotEmpty()): ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.table-titles','data' => ['addAction' => ''.e($addAction).'']]); ?>
<?php $component->withName('table-titles'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['addAction' => ''.e($addAction).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            <?php endif; ?>
            </tfoot>
        </table>
    </div>
</div>
<?php /**PATH /var/www/html/resources/views/components/table.blade.php ENDPATH**/ ?>