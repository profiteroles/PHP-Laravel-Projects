<?php $attributes = $attributes->exceptProps(['priority'=>false, 'title','href']); ?>
<?php foreach (array_filter((['priority'=>false, 'title','href']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<form action="<?php echo e($href ?? ''); ?>" method="POST" class="text-red-500 flex-initial pr-2.5 hover:text-primary">
    <?php echo csrf_field(); ?>
    <?php echo method_field('patch'); ?>
    <button type="submit">

        <div class="relative inline-block w-10 mr-2 align-middle select-none transition duration-200 ease-in">
            <input type="checkbox" name="priority" id="<?php echo e($title); ?>" <?php echo e($priority ? 'checked' : ''); ?>

            class="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer"/>
            <label for="<?php echo e($title); ?>"
                   class="toggle-label block overflow-hidden h-6 rounded-full bg-gray-300 cursor-pointer"></label>
        </div>
    </button>

    <label for="toggle" class="text-xs text-white"><?php echo e($priority ? 'Prioritised' : 'Not Prioritised'); ?></label>
</form>
<?php /**PATH /var/www/html/resources/views/components/toggle.blade.php ENDPATH**/ ?>