<?php $attributes = $attributes->exceptProps(['delbtn'=>false, 'title'=>'title','addAction','id']); ?>
<?php foreach (array_filter((['delbtn'=>false, 'title'=>'title','addAction','id']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<tr>
    <?php if($delbtn): ?>
        <th>
            <label for="my-modal-2" class="btn btn-primary modal-button">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24"
                     stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                </svg>
            </label>
            <input type="checkbox" id="my-modal-2" class="modal-toggle">
            <div class="modal">
                <div class="modal-box">
                    <p>Would you like to all the list items?</p>
                    <form
                        action="<?php echo e(Request()->route()->getName() == 'index' ? route('deleteAllList'): route('deleteAll',[$id])); ?>"
                        method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <div class="modal-action">
                            <button type="submit">
                                <label for="my-modal-2" class="btn btn-primary">Yeap</label>
                            </button>
                            <label for="my-modal-2" class="btn">Nah Nah</label>
                        </div>
                    </form>
                </div>
            </div>
        </th>
    <?php else: ?>
        <th></th>
    <?php endif; ?>
    <th><?php echo e($title); ?></th>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.addbtn','data' => ['addAction' => ''.e($addAction).'']]); ?>
<?php $component->withName('addbtn'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['addAction' => ''.e($addAction).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
</tr>
<?php /**PATH /var/www/html/resources/views/components/table-titles.blade.php ENDPATH**/ ?>