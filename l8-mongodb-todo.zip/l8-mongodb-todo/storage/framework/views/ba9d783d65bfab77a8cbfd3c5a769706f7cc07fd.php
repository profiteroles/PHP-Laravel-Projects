<?php $attributes = $attributes->exceptProps(['addAction'=>'', 'list_id'=> '']); ?>
<?php foreach (array_filter((['addAction'=>'', 'list_id'=> '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<th x-data={showInput:false}>
    <div x-show="showInput" class="form-control">
        <div class="relative">
            <form action="<?php echo e($addAction); ?>" method="POST" autocomplete="off">
                <?php echo csrf_field(); ?>
                <input type="number" value="{{}}" name="todolist_id" hidden>
                <input type="text" name="title" placeholder="Add New One"
                       class="w-full pr-16 input input-primary input-bordered">
                <button x-on:click="showInput=!showInput" type="submit"
                        class="absolute top-0 right-0 rounded-l-none btn btn-primary">+
                </button>
            </form>
        </div>
    </div>
    <button @click="showInput=!showInput" type="button" x-transition >
        <template x-if="!showInput">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24"
                 stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                      d="M12 9v3m0 0v3m0-3h3m-3 0H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z"/>
            </svg>
        </template>
    </button>
</th>
<?php /**PATH /var/www/html/resources/views/components/addbtn.blade.php ENDPATH**/ ?>