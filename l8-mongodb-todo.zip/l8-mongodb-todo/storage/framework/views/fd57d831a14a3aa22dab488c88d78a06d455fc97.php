<div x-data="{
        onValue: <?php echo e(json_encode($onValue)); ?>,
        offValue: <?php echo e(json_encode($offValue)); ?>,
        <?php if($hasWireModel()): ?>
            value: @entangle($attributes->wire('model')),
        <?php elseif($hasXModel()): ?>
            value: <?php echo e($attributes->first('x-model')); ?>,
        <?php else: ?>
            value: <?php echo e(json_encode($value)); ?>,
        <?php endif; ?>
        get isPressed() {
            return this.value === this.onValue;
        },
        toggle() {
            this.value = this.isPressed ? this.offValue : this.onValue;
        },
     }"
     wire:ignore.self
     class="<?php echo e($getContainerClass()); ?>"
     <?php if($hasXModel()): ?>
         x-init="$watch(value, newValue => { <?php echo e($attributes->first('x-model')); ?> = newValue })"
     <?php endif; ?>
     <?php echo e($extraAttributes); ?>

>
    <?php if($label && $labelPosition === 'left'): ?>
        <span x-on:click="$refs.button.click(); $refs.button.focus();"
              class="flex-grow switch-toggle-label form-label block text-sm font-medium leading-5 text-blue-gray-700"
              id="<?php echo e($labelId()); ?>"
        >
            <?php echo e($label); ?>

        </span>
    <?php endif; ?>

    <button x-bind:aria-pressed="JSON.stringify(isPressed)"
            x-on:click="toggle()"
            x-ref="button"
            x-cloak
            type="button"
            <?php if($id): ?> id="<?php echo e($id); ?>" <?php endif; ?>
            <?php if($label): ?> aria-labelledby="<?php echo e($labelId()); ?>" <?php endif; ?>
            <?php echo e($attributes->except(['type', 'wire:model', 'wire:model.defer', 'wire:model.lazy', 'x-model'])->merge(['class' => $buttonClass()])); ?>

            x-bind:class="{ 'pressed': isPressed }"
            <?php if($disabled): ?> disabled <?php endif; ?>
    >
        <span class="sr-only"><?php echo e(__($buttonLabel)); ?></span>

        <?php if($short): ?>
            <span aria-hidden="true"
                  class="switch-toggle-short-bg"
                  x-bind:class="{ 'pressed': isPressed }"
            >
            </span>

            <span aria-hidden="true"
                  class="switch-toggle-short-button"
                  x-bind:class="{ 'pressed': isPressed }"
            >
            </span>
        <?php else: ?>
            <span aria-hidden="true"
                  class="switch-toggle-button"
                  x-bind:class="{ 'pressed': isPressed }"
            >
                <?php if($offIcon): ?>
                    <span class="absolute inset-0 h-full w-full flex items-center justify-center transition-opacity"
                          x-bind:class="{ 'opacity-0 ease-out duration-100': isPressed, 'opacity-100 ease-in duration-200': ! isPressed }"
                          aria-hidden="true"
                    >
                        <?php echo e($offIcon); ?>

                    </span>
                <?php endif; ?>

                <?php if($onIcon): ?>
                    <span class="absolute inset-0 h-full w-full flex items-center justify-center transition-opacity"
                          x-bind:class="{ 'opacity-100 ease-in duration-200': isPressed, 'opacity-0 ease-out duration-100': ! isPressed }"
                          aria-hidden="true"
                    >
                        <?php echo e($onIcon); ?>

                    </span>
                <?php endif; ?>
            </span>
        <?php endif; ?>
    </button>

    <?php if($label && $labelPosition === 'right'): ?>
        <span x-on:click="$refs.button.click(); $refs.button.focus()"
              class="ml-3 switch-toggle-label form-label block text-sm font-medium leading-5 text-blue-gray-700"
              id="<?php echo e($labelId()); ?>"
        >
            <?php echo e($label); ?>

        </span>
    <?php endif; ?>

    <?php if($name): ?>
        <input type="hidden" name="<?php echo e($name); ?>" x-bind:value="JSON.stringify(value)" />
    <?php endif; ?>
</div>
<?php /**PATH /var/www/html/vendor/rawilk/laravel-form-components/src/../resources/views/components/choice/switch-toggle.blade.php ENDPATH**/ ?>